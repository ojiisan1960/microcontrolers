#!/bin/bash

mkdir ${1}

cat > ${1}/${1}.ino << EOF
/*****


*****/
EOF
