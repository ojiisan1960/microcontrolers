# cloud-lightning

[![Lightning cloud](http://i.imgur.com/79LUuV7.png)](https://www.youtube.com/watch?v=XxMMNcU-hWE "Click to see the video")

A little lightning cloud for fun. [Full Instructable available here](http://www.instructables.com/id/How-to-make-a-Lightning-Cloud/)


##Early prototypes:
https://www.youtube.com/watch?v=283USS50E_s
